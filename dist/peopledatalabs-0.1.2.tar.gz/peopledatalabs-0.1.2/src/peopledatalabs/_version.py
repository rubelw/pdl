"""
Base version for peopledatalabs with the build number appended
in __init__
"""

__version__ = "0.1.0"